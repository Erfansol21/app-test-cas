package com.example.FoodFrenzyUserPurchase;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.apache.commons.io.FileUtils;
import java.io.File;

public class KatalonTest {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  JavascriptExecutor js;
  @Before
  public void setUp() throws Exception {
    System.setProperty("webdriver.chrome.driver", "");
    driver = new ChromeDriver();
    baseUrl = "https://www.google.com/";
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
    js = (JavascriptExecutor) driver;
  }

  @Test
  public void testKatalon() throws Exception {
    driver.get("http://localhost:8080/register");
    driver.findElement(By.id("u_id")).click();
    driver.findElement(By.id("u_id")).clear();
    driver.findElement(By.id("u_id")).sendKeys("99");
    driver.findElement(By.id("uemail")).clear();
    driver.findElement(By.id("uemail")).sendKeys("test99@test.com");
    driver.findElement(By.id("uname")).clear();
    driver.findElement(By.id("uname")).sendKeys("test99");
    driver.findElement(By.id("unumber")).clear();
    driver.findElement(By.id("unumber")).sendKeys("9999999999");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.get("http://localhost:8080/login");
    driver.findElement(By.id("email")).clear();
    driver.findElement(By.id("email")).sendKeys("test99@test.com");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("1234");
    driver.findElement(By.id("userEmail")).clear();
    driver.findElement(By.id("userEmail")).sendKeys("test99@test.com");
    driver.findElement(By.id("userPassword")).clear();
    driver.findElement(By.id("userPassword")).sendKeys("1234");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Password:'])[2]/following::button[1]")).click();
    driver.get("http://localhost:8080/userLogin");
    driver.findElement(By.name("productName")).click();
    driver.findElement(By.name("productName")).clear();
    driver.findElement(By.name("productName")).sendKeys("Olive Oil");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.get("http://localhost:8080/product/search");
    driver.findElement(By.name("oQuantity")).click();
    driver.findElement(By.name("oQuantity")).clear();
    driver.findElement(By.name("oQuantity")).sendKeys("1");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='SEARCH'])[1]/following::button[1]")).click();
    driver.get("http://localhost:8080/product/order");
    driver.findElement(By.linkText("Back")).click();
    driver.get("http://localhost:8080/product/back");
    driver.findElement(By.name("productName")).click();
    driver.findElement(By.name("productName")).click();
    driver.findElement(By.name("productName")).clear();
    driver.findElement(By.name("productName")).sendKeys("Chicken Breast");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.get("http://localhost:8080/product/search");
    driver.findElement(By.name("oQuantity")).click();
    driver.findElement(By.name("oQuantity")).clear();
    driver.findElement(By.name("oQuantity")).sendKeys("1");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='SEARCH'])[1]/following::button[1]")).click();
    driver.get("http://localhost:8080/product/order");
    driver.findElement(By.linkText("Back")).click();
    driver.get("http://localhost:8080/product/back");
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
